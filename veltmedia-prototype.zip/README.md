# VELT MEDIA — Post-Production Agency Website

Production-ready, performance-optimized static website for **VELT MEDIA**.

## What Was Upgraded
- **Asset Optimization (~31 MB → ~1.5 MB)**: Compressed and resized portrait images (`imgs/`) and reel thumbnails (`thumbnails/`) for instant mobile decoding and zero scroll stutter, and removed unused assets.
- **Mobile View & Responsive UX**:
  - Removed the `@media (max-width: 700px) { transform: none !important; }` override that blocked GSAP scroll-reveal animations on mobile devices.
  - Fixed Team portrait framing (`width: 100%; height: 100%; object-fit: cover; object-position: center top`) and removed leftover placeholder border boxes.
  - Upgraded the mobile navigation drawer with a dedicated **"Book a 48H Slot"** CTA, social quick-links, `Escape`-key dismissal, and viewport-resize reset.
  - Added `scroll-padding-top` to `html` so anchor navigation lands cleanly below the fixed glass header.
- **Smoothness & Interactivity**:
  - **4-Card Balanced Bento Gallery + Live Category Filtering**: Eliminated the empty 5th grid cell and added instant category filtering (`All`, `Automotive`, `Brand Campaign`, `Social Media`).
  - **Interactive Service Selection & Booking Scope Configurator**: Clicking any service card or project scope pill updates the pre-filled inquiry and scrolls smoothly to the booking CTA.
  - **One-Tap Email Copy & Toast Notification**: Added a `Copy` button next to `veltmedia7@gmail.com` with clipboard support and an in-page toast notification.
  - **Testimonials Controls**: Kept all `[INSERT_TESTIMONIAL_HERE]` placeholders intact for future updates while adding a Pause/Resume toggle and mobile touch-scroll support.
  - **Top Scroll Progress Bar & Floating Back-to-Top Button**: GPU-accelerated scroll indicator and quick return button.

## Quick Deployment

### 1. Deploy to Vercel
1. Push this repository to GitHub, GitLab, or Bitbucket.
2. Import the repository at [vercel.com/new](https://vercel.com/new) (no build command required; `vercel.json` is pre-configured with long-term asset caching).

### 2. Deploy to Netlify
1. Drag and drop this folder at [app.netlify.com/drop](https://app.netlify.com/drop) or connect your Git repository (`netlify.toml` is pre-configured).

### 3. Deploy to GitHub Pages
1. In your GitHub repository, go to **Settings → Pages**.
2. Under **Build and deployment**, select **Deploy from a branch** → `main` (root `/`) and click **Save**.
